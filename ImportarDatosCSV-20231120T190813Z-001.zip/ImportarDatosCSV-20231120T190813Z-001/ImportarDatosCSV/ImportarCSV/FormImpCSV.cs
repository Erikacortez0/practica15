﻿using System;
using System.Diagnostics.Eventing.Reader;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace ImportarCSV
{
    public partial class formImpCSV : Form
    {
        public formImpCSV()
        {
            InitializeComponent();
        }

        private void btImportarCSV_Click(object sender, EventArgs e)
        {
            string separador = txtSeparador.Text;
            if(separador == "")
            {
                MessageBox.Show("Debe indicar el separador de columna " +
                "CSC. se separa por cosas o puntos y comas ", "Fichero CSV vacio",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
              txtSeparador.Focus();
            }
            else
            {
                OpenFileDialog selCSV = new OpenFileDialog();
                selCSV.InitialDirectory = "C:\\";
                selCSV.Filter = "CSV (*.cvs)|*.csv| Todos los archivos (*.*)|*.*";
                selCSV.FilterIndex = 1;
                selCSV.RestoreDirectory = true;
                if (selCSV.ShowDialog() == DialogResult.OK)
                {
                    string ficheroCSV = selCSV.FileName;

                    //establecer las propiedades de lsitviem
                    lsCSV.View = View.Details;
                    lsCSV.GridLines = true;
                    lsCSV.FullRowSelect = true;
                    lsCSV.Items.Clear();

                    try
                    {
                        //obtener la codificacion de nuestro
                        Encoding codificacion = Encoding.UTF8;
                        if (lsCodificacion.Text == "UTF8")
                            codificacion = Encoding.UTF8;


                        //recorremos todas ls filas del ficheo
                        var lineasCVS = File.ReadLines(ficheroCSV, codificacion);

                        //comprobamos que elñ fichero noeste vacio
                        if (lineasCVS.Count() == 0)
                            MessageBox.Show($"El fichero CSV seleccionado [{ficheroCSV}] esta vacion",
                                "Intente con optro archivo",
                                 MessageBoxButtons.OK, MessageBoxIcon.Exclamation);

                        else
                        {
                            string valorActual = "";

                            //si tomamos la primera fila como titulo
                            if (opTitulos.Checked)
                            {
                                var LineaTitulos = File.ReadLines(ficheroCSV, codificacion).First();
                                string[] columnastitulos = LineaTitulos.Split(Convert.ToChar(separador));

                                //añadimos las colummnas a nuestro listViem
                                for (int i = 0; i < columnastitulos.Count(); i++)
                                {
                                    if (opComillas.Checked)
                                        valorActual = columnastitulos[i].Trim(Convert.ToChar(lsComillas.Text));
                                    else
                                        valorActual = columnastitulos[i];
                                    lsCSV.Columns.Add(valorActual);
                                }
                            }
                            int numLinea = 0;
                            foreach (string lineaActual in lineasCVS)
                            {
                                numLinea++;
                                if (opTitulos.Checked && numLinea == 1)
                                    continue;

                                string[] columnasLineasCSV = lineaActual.Split(Convert.ToChar(separador));
                                if (opComillas.Checked)
                                    valorActual = columnasLineasCSV[0].Trim(Convert.ToChar(lsComillas.Text));
                                else
                                    valorActual = columnasLineasCSV[0];

                                ListViewItem filasListView = new ListViewItem(valorActual);

                                for (int i = 1;  i < columnasLineasCSV.Count(); i++)
                                {
                                    if (opComillas.Checked)
                                        filasListView.SubItems.Add(columnasLineasCSV[i].Trim(Convert.ToChar(lsComillas.Text)));
                                    else
                                        filasListView.SubItems.Add(columnasLineasCSV[i]);
                                }
                                lsCSV.Items.Add(filasListView);

                            }

                        }
                    }
                    catch (Exception error)
                    {
                        MessageBox.Show($"Error al leer fichero CSV: {error.Message}",
                            "Error", MessageBoxButtons.OK, MessageBoxIcon.  Exclamation);
                    }
                }
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
